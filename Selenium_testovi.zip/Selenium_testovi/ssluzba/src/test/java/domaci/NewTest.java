package domaci;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;

public class NewTest{
	
	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private String baseUrl;
	private MenuPage menuPage;
	
	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		//driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		
		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		menuPage = new MenuPage(driver);
		
		
		
	}
	
	@Test
	public void login() throws InterruptedException  {
		assertEquals(baseUrl, driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());
		
		loginPage.login("djura@djuraminis.com", "adminvinca");
		
//		WebDriverWait wait = new WebDriverWait(driver, 10);
//		ExpectedCondition e = new ExpectedCondition<Boolean>() {
//	          public Boolean apply(WebDriver d) {
//	            return (d.getCurrentUrl() != baseUrl + "login");
//	          }
//	        };
//
//	    wait.until(e);
//	    
//		
//	    System.out.println(driver.getCurrentUrl());
//	    assertTrue(driver.findElement(By.xpath("//form[@name='Basic']")). isDisplayed());
//	    
//	    
//	    driver.findElement(By.xpath("//a[@class='select2-choice']")).click();
//	    driver.findElement(By.id("s2id_autogen2_search")).sendKeys("Steva");
//		assertTrue(driver.findElement(By.xpath("//option[text()='Steva Stevic institucija']")).isDisplayed());
//		//driver.findElement(By.xpath("//ul[@id='select2-results-2']//text()[contains(.,'Steva Stevic')]/../..")).click();
//	    driver.findElement(By.xpath("//option[text()='Steva Stevic institucija']")).click();
//	    assertTrue(driver.findElement(By.xpath("//option[text()='Steva Stevic institucija']")).isSelected());
	    
	    
	   
	    
	    
	    
	    
//	    Select dropdown = new Select(driver.findElement(By.name("supetInstitution")));
//	    dropdown.selectByVisibleText("Steva Stevic institucija");
	    
		//Provere tabova
		
		//WebElement formaOsnovna = instOsnovniPage.getFormaCela();
		//assertTrue(formaOsnovna.isDisplayed());
		assertTrue(menuPage.getOsnovniPodaci().isDisplayed());
		assertTrue(menuPage.getOsnovniPodaci().isEnabled());
		assertTrue(menuPage.getPodaciZaRegistar().isDisplayed());
		assertTrue(menuPage.getPodaciZaRegistar().isEnabled());
		assertTrue(menuPage.getPodaciZaProjekte().isDisplayed());
		assertTrue(menuPage.getPodaciZaProjekte().isEnabled());
		
		//assertTrue(menuPage.getUvecajLink().isDisplayed());
		assertEquals(menuPage.getNaslov(), "MINIS");
		
		
		//provera da li su neki inputi tu
//		assertTrue(instOsnovniPage.getNazivInstitucije().isDisplayed());
//		assertTrue(instOsnovniPage.getDrzava().isDisplayed());
		
		
		//provera da li ispisuje greske
		instOsnovniPage.getNazivInstitucije().clear();
		instOsnovniPage.getSaveBtn().click();
		assertTrue(instOsnovniPage.getNazivError().isDisplayed());
		
		//Unos naziva institucije
		instOsnovniPage.setNazivInstitucije("Mirko Cabrilo");
		String nazivInstitucije = instOsnovniPage.getNazivInstitucije().getAttribute("value");
		assertEquals(nazivInstitucije,"Mirko Cabrilo" );
		
		
		/*//Unos nove drzave
		instOsnovniPage.getNovaDrzavaAppear();
		assertTrue(instOsnovniPage.getImeNoveDrzave().isDisplayed());
		assertTrue(instOsnovniPage.getOpisNoveDrzave().isDisplayed());
		assertTrue(instOsnovniPage.getConfirmButton().isDisplayed());
		instOsnovniPage.unesiNovuDrzavu("Bugarska","");
		Thread.sleep(3000);
		assertTrue(instOsnovniPage.getDrzava().isDisplayed());
		String izabranaDrzava=instOsnovniPage.getSelectedState();
		assertEquals(izabranaDrzava, "Bugarska");
		*/
		//Unos postojece drzave
		instOsnovniPage.setDrzavaByLabel("Bugarska");
		String izabranaPostojecaDrzava = instOsnovniPage.getSelectedState();
		assertEquals(izabranaPostojecaDrzava, "Bugarska");
		
		
		//Unos nadredjene institucije
		/*instOsnovniPage.setNadredjenaInstitucija("steva");
		assertTrue(instOsnovniPage.getOption("Steva Stevic institucija").isSelected());
		*/
		
		//Unos nadredjene institucije koja ne postoji
		/*assertTrue(instOsnovniPage.getListaInstitucija().isDisplayed());
		instOsnovniPage.getListaInstitucija().click();
		assertTrue(instOsnovniPage.getUnosBtn().isDisplayed());
		instOsnovniPage.setUnosBtn("kpl");
		String poruka= instOsnovniPage.getNoInst().getText();
		assertEquals(poruka, "No matches found");
		*/
		
		instOsnovniPage.getSaveBtn().click();
	}
	
/*	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}
	*/
	
	
	
	
	

}
