package domaci;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class LoginNegativniTest {
	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;
	private MenuPage menuPage;
	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		// driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		menuPage=new MenuPage(driver);
		//loginPage.login("djura@djuraminis.com", "adminvinca");
	}
  @Test
  // negativni testovi za login
  public void loginWithoutUsername() {
	  loginPage.login("", "adminvinca");
	  //Potvrdjujemo da je button Prijavi se - Disabled.
	  Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
  }
  @Test
  public void loginWithoutPassword() {
	  loginPage.login("djura@djuraminis", "");
	  //Potvrdjujemo da je button Prijavi se - Disabled.
	  Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
  }
 
}
