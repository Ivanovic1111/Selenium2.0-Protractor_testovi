/*package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.pages.IstrazivaciCreationPage;
import svetlana.minis.pages.IstrazivaciListPage;
import svetlana.minis.pages.IstrazivaciPodaciRegistarPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddIstrazivacPodaciZaRegistar {

	private WebDriver driver;
	private LoginPage loginPage;
	private MenuPage menuPage;
	private IstrazivaciCreationPage istrazivaciCreationPage;
	private IstrazivaciListPage istrazivaciListPage;
	private String baseUrl;
	private SuccessModalPage successModalPage;
	private IstrazivaciPodaciRegistarPage istrazivaciPodRegistar;
// Test nije implementiran nedostaju podaci
	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		menuPage = new MenuPage(driver);
		istrazivaciCreationPage = new IstrazivaciCreationPage(driver);
		istrazivaciListPage = new IstrazivaciListPage(driver);
		successModalPage = new SuccessModalPage(driver);
		istrazivaciPodRegistar = new IstrazivaciPodaciRegistarPage(driver);
	}
// @ Istrazivaci - PODACI ZA REGISTAR
	@Test
	public void login() {
		assertEquals(baseUrl, driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());

		loginPage.login("djura@djuraminis.com", "adminvinca");
		// WebElement formaOsnovna = institucijaOsnovniPage.getFormaCela();
		// assertTrue(formaOsnovna.isDisplayed());
		// Nedovrseno
		menuPage.getIstrazivaciLink().click();
		istrazivaciListPage.getDodajIstrazivaca().click();
		menuPage.getPodaciZaRegistar().click();
		istrazivaciPodRegistar.setBibliografija("bibliografija");
		istrazivaciPodRegistar.setOblastIstrazivanja("oblastIstrazivanja");
		istrazivaciPodRegistar.setIdentBrojUMinistarstvu("identBrojUMinistarstvu");
		istrazivaciCreationPage.getSaveBtn().click();
	}

	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}
}
*/