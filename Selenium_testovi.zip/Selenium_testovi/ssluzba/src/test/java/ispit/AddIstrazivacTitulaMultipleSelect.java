package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.pages.IstrazivaciCreationPage;
import svetlana.minis.pages.IstrazivaciListPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddIstrazivacTitulaMultipleSelect {

	private WebDriver driver;
	private LoginPage loginPage;
	private MenuPage menuPage;
	private IstrazivaciCreationPage istrazivaciCreationPage;
	private IstrazivaciListPage istrazivaciListPage;
	private String baseUrl;
	private SuccessModalPage successModalPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		menuPage = new MenuPage(driver);
		istrazivaciCreationPage = new IstrazivaciCreationPage(driver);
		istrazivaciListPage = new IstrazivaciListPage(driver);
		successModalPage = new SuccessModalPage(driver);
		loginPage.login("djura@djuraminis.com", "adminvinca");

	}

	@Test
	public void login(){
		menuPage.getIstrazivaciLink().click();
		istrazivaciListPage.getDodajIstrazivaca().click();

		// WebElement formaOsnovna = institucijaOsnovniPage.getFormaCela();
		// assertTrue(formaOsnovna.isDisplayed());

		assertTrue(istrazivaciCreationPage.getIme().isDisplayed());
		istrazivaciCreationPage.setIme("Svetlana");
		istrazivaciCreationPage.setDatum("20.02.2003.");

		istrazivaciCreationPage.setPrezime("Ivanovic");
	
		// *************************************************************************//
		//ovde u testu pravimo praznu listu i ubacujemo polja za selekciju u listu.
		ArrayList<String> personTitle = new ArrayList<String>();
		personTitle.add("нема");
		personTitle.add("Dr");
		istrazivaciCreationPage.setTitulaByLabel(personTitle);
		// ************************************************************************//

	//istrazivaciCreationPage.selectTheDropDownList("Mr");
		istrazivaciCreationPage.setJmbg("1212201222343");
		istrazivaciCreationPage.getSaveBtn().click();

		// ovde pisem asertacije da li sadrzi prezime istrazivac
		// assertTrue(successModalPage.getModal().isDisplayed());
	}
	@Test
	public void addIstrazivacPogresanDatum() {
		// WebElement dodajIstrazivaca = menuPage.getDodajIstrazivaca();
		// assertTrue(dodajIstrazivaca.isDisplayed());
		menuPage.getIstrazivaciLink().click();
		istrazivaciListPage.getDodajIstrazivaca().click();
		istrazivaciCreationPage.setIme("Svetlana");
		istrazivaciCreationPage.setPrezime("Ivanovic");
		istrazivaciCreationPage.setDatum("1.23.2003.");
		istrazivaciCreationPage.getSaveBtn().click();
		String poruka = "Датум рођења мора бити у формату ДД.ММ.ГГГГ";
		Assert.assertEquals(poruka, istrazivaciCreationPage.getDatumError().getText());
	}
// @ Testiramo pozitivan unos istrazivaca 
	@Test
	public void dodajIstrazivaca() {
		menuPage.getIstrazivaciLink().click();
		istrazivaciListPage.getDodajIstrazivaca().click();
		istrazivaciCreationPage.setIme("Svetlana");
		istrazivaciCreationPage.setPrezime("Ivanovic");
		istrazivaciCreationPage.setJmbg("1238438383948");
		istrazivaciCreationPage.getSaveBtn().click();

	}

	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}
}
