package ispit;

import static org.testng.Assert.*;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddInstitucijaWebAdresaCssValue {

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();

		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		// driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		loginPage.login("djura@djuraminis.com", "adminvinca");

		WebElement formaOsnovna = instOsnovniPage.getFormaCela();
		assertTrue(formaOsnovna.isDisplayed());

		assertTrue(instOsnovniPage.getNazivInstitucije().isDisplayed());
	}

	@Test
	public void setForma() {
		instOsnovniPage.setWebAdresa("www.vin.com");
		instOsnovniPage.getWebAdresa().clear();
		instOsnovniPage.getSaveBtn().click();
		Assert.assertTrue(instOsnovniPage.getWebAdresa().getCssValue("border-top-color:").contains("221, 75, 57)"));
	}
}
