package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.LoginPage;

public class TestLogin {

	private WebDriver driver;
	private LoginPage loginPage;
	private String baseUrl;
		
	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		//driver.manage().window().maximize();
		driver.navigate().to(baseUrl);
		
		loginPage = new LoginPage(driver);
				
	}
	
	@Test
	public void login() throws InterruptedException  {
		//assertEquals(baseUrl , driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());
		
		loginPage.setUserName("abcd");
		loginPage.getUserName().clear();
		
		//check login username message
	
		String message = driver.findElement(By.xpath("//span[text()='Korisničko ime obavezno']")).getText();	
		String expectedMessage = "Korisničko ime obavezno";
		
		assertEquals(expectedMessage, message);
		
		//check login password message
		
		loginPage.setPassword("qwer");
		loginPage.getPassword().clear();
		
		String passwordMessage = driver.findElement(By.xpath("//span[text()='Lozinka obavezna']")).getText();	
		String expectedPasswordMessage = "Lozinka obavezna";
		
		assertEquals(expectedPasswordMessage, passwordMessage);

		// check login sa neispravnim username
		
		loginPage.getUserName().clear();
		loginPage.setUserName("mmmm");
		loginPage.getPassword().clear();
		loginPage.setPassword("cccc");
		loginPage.getSignInBtn().click();
		
		
		String loginErrorMessage = loginPage.getLogError().getText();
		String expectedLoginErrorMessage = "Pogrešno korisničko ime ili lozinka!";
		assertEquals(expectedLoginErrorMessage, loginErrorMessage);
		
	
	
	}
	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}
}
