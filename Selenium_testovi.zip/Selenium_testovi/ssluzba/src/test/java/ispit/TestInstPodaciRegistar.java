package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.InstitucijaRegistarPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;

public class TestInstPodaciRegistar {

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaRegistarPage instRegistarPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private MenuPage menuPage;
	private String baseUrl;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instRegistarPage = new InstitucijaRegistarPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		menuPage = new MenuPage(driver);

	}
	//Testiramo prazna polja kod Institucija-Podaci za registar
	@Test
	public void registracijaPodaci()   {
		assertEquals(baseUrl, driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());
		loginPage.login("djura@djuraminis.com", "adminvinca");
		menuPage.getPodaciZaRegistar().click();
		WebElement formaRegistracija = instRegistarPage.getForm();
		assertTrue(formaRegistracija.isDisplayed());
       instRegistarPage.setInstitucijaPodaciZaRegistar("", "", "", "", "","Istraživački centar","Државна");
		instRegistarPage.getSaveBtn().click();

		assertTrue(instRegistarPage.getPibError().isDisplayed());
		assertTrue(instRegistarPage.getMaticniBrojError().isDisplayed());
		assertTrue(instRegistarPage.getBrojPoslednjeAkredError().isDisplayed());
		assertTrue(instRegistarPage.getNazivInstitucijeAkredError().isDisplayed());
	}
	//Testiramo pogresan PIB 
	@Test
	public void proveraUnosaPiba(){
		loginPage.login("djura@djuraminis.com", "adminvinca");
		menuPage.getInstitucijaLink().click();
		menuPage.getPodaciZaRegistar().click();
		instRegistarPage.setPib("123@#%");
		//String pibText = instRegistarPage.getPib().getAttribute("value");
		instRegistarPage.getSaveBtn().click();
		Assert.assertTrue(instRegistarPage.getPIBError().isDisplayed());
	}
	//Testiramo pogresan unos maticnog broja
	@Test
	public void proveraUnosaMaticnogBroja(){
		loginPage.login("djura@djuraminis.com", "adminvinca");
		menuPage.getInstitucijaLink().click();
		menuPage.getPodaciZaRegistar().click();
		instRegistarPage.setPib("1223");
		instRegistarPage.setMaticniBroj("");
		instRegistarPage.setDatumPoslednjeAkred("20.02.2017");
		instRegistarPage.setNazivInstitucijeAkred("Institucija");
		instRegistarPage.setInstitucijaByLabel("Istraživački centar");
		instRegistarPage.setVlasnickaStrukturaByLabel("Државна");
    	instRegistarPage.getSaveBtn().click();
    	String message="Унесите матични број.";
    	Assert.assertEquals(instRegistarPage.getMaticniBrojError().getText(), message);
			
		}
	
	@AfterClass
	public void closeDriver(){
		loginPage.getIconLogout().click();
		loginPage.getOdjavaToBeClicked().click();
		driver.close();
	}
}

