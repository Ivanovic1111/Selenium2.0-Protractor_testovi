package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class LoginNegativniTest {
	public static String getNCharacters(int n) {
		StringBuffer outputBuffer = new StringBuffer(n);
		for (int i = 0; i < n; i++) {
			outputBuffer.append("a");
		}
		return outputBuffer.toString();
	}

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;
	private MenuPage menuPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		// driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		menuPage = new MenuPage(driver);
		// loginPage.login("djura@djuraminis.com", "adminvinca");
	}

	// Negativni testovi za login, testiramo podatke koji ne bi trebali da se
	// stavljaju
	@Test
	// login bez username
	public void loginWithoutUsername() {
		loginPage.login("", "adminvinca");
		// Potvrdjujemo da je button Prijavi se - Disabled.
		Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
	}

	// Login bez password
	@Test
	public void loginWithoutPassword() {
		loginPage.login("djura@djuraminis", "");
		// Potvrdjujemo da je button Prijavi se - Disabled.
		Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
	}

	// Prazno polje passworda i username
	@Test
	public void loginWithEmptyPasswordAndEmptyUsername() {
		loginPage.login("", "");
		// Potvrdjujemo da je button Prijavi se - Disabled.
		Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
		Assert.assertTrue(loginPage.getCancelBtn().isDisplayed());
	}

	// Testiramo unos praznog polja username, ocekujemo da je dugme prijavi se
	// onemoguceno
	// Prazno polje username
	@Test
	public void loginPasswordLenght() {
		loginPage.setUserName(getNCharacters(0));
		loginPage.setPassword(getNCharacters(3000));
		Assert.assertFalse(loginPage.getSignInBtn().isEnabled());
	}

	@Test
	public void usernameShouldNotHaveSymbolsInTheField() {
		loginPage.login("@@@@@@@@@@@@@@@@", "adminvinca");
		Assert.assertTrue(loginPage.getLogError().getText().contains("Pogrešno korisničko ime ili lozinka!"));
	}

	public void loginWithoutUsernameMsgError() {
		// assertEquals(baseUrl , driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());
		loginPage.setUserName("abcd");
		loginPage.getUserName().clear();
		String expectedMessage = "Korisničko ime obavezno";
		Assert.assertEquals(expectedMessage, loginPage.getUsernameError().getText());
	}

	public void loginWithoutPasswordErrorMsg() {
		loginPage.setPassword("Sifra");
		loginPage.getPassword().clear();
		Assert.assertTrue(loginPage.getPasswordError().getText().contains("Pogrešna lozinka"));
	}
}