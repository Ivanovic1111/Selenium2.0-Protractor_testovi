package ispit;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.helpers.Utils;
import svetlana.minis.pages.IstrazivaciCreationPage;
import svetlana.minis.pages.IstrazivaciListPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddIstrazivac {
	
	private WebDriver driver;
	private LoginPage loginPage;
	private MenuPage menuPage;
	private IstrazivaciCreationPage istrazivaciCreationPage;
	private IstrazivaciListPage istrazivaciListPage;
	private String baseUrl;
	private SuccessModalPage successModalPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		menuPage = new MenuPage(driver);
		istrazivaciCreationPage= new IstrazivaciCreationPage(driver);
		istrazivaciListPage = new IstrazivaciListPage(driver);
		successModalPage = new SuccessModalPage(driver);
	}

	@Test
	public void login()  {
		assertEquals(baseUrl, driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());

		loginPage.login("djura@djuraminis.com", "adminvinca");
		//		WebElement formaOsnovna = institucijaOsnovniPage.getFormaCela();
		//		assertTrue(formaOsnovna.isDisplayed());
// @ dodavanje istrazivaca bez imena
		menuPage.getIstrazivaciLink().click();
		WebElement tabela= istrazivaciListPage.getIstrazivaciTable();
		assertTrue(tabela.isDisplayed());
		istrazivaciListPage.getDodajIstrazivaca().click();
		assertTrue(istrazivaciCreationPage.getIme().isDisplayed());
		istrazivaciCreationPage.setIme("");
		istrazivaciCreationPage.setPrezime("Ivanovic");
		istrazivaciCreationPage.setJmbg("1212201222343");
		istrazivaciCreationPage.getSaveBtn().click();
		Assert.assertTrue(istrazivaciCreationPage.getImeError().isDisplayed());
//ovde pisem asertacije da li sadrzi prezime istrazivac
		//assertTrue(successModalPage.getModal().isDisplayed());
	}
	// @ datum u pogresnom formatu
	@Test
	public void addIstrazivacPogresanDatum() {
		loginPage.login("djura@djuraminis.com", "adminvinca");
		//WebElement dodajIstrazivaca = menuPage.getDodajIstrazivaca();
		//assertTrue(dodajIstrazivaca.isDisplayed());
		menuPage.getIstrazivaciLink().click();
		istrazivaciListPage.getDodajIstrazivaca().click();
		istrazivaciCreationPage.setIme("Svetlana");
		istrazivaciCreationPage.setPrezime("Ivanovic");
		istrazivaciCreationPage.setDatum("1.23.2003.");
		istrazivaciCreationPage.getSaveBtn().click();
		String poruka="Датум рођења мора бити у формату ДД.ММ.ГГГГ";
		Assert.assertEquals(poruka, istrazivaciCreationPage.getDatumError().getText());
		
	}
	// dodavanje istrazivaca bez imena
@Test
public void dodajIstrazivacaBezImena(){
	loginPage.login("djura@djuraminis.com","adminvinca");
	menuPage.getNaslovClick().click();
	menuPage.getIstrazivaciLink().click();
	istrazivaciListPage.getDodajIstrazivaca().click();
	istrazivaciCreationPage.setIme("");
	istrazivaciCreationPage.setPrezime("Ivanovic");
	istrazivaciCreationPage.getSaveBtn().click();
	String poruka="Морате унети име.";
	Assert.assertEquals(poruka, istrazivaciCreationPage.getImeError().getText());
}
// @ alert se javlja kada se ne unese prezime
@Test
public void istrazivacBezPrezimena(){
	loginPage.login("djura@djuraminis.com","adminvinca");
	menuPage.getNaslovClick().click();
	menuPage.getIstrazivaciLink().click();
	istrazivaciListPage.getDodajIstrazivaca().click();
	istrazivaciCreationPage.setIme("Svetlana");
	istrazivaciCreationPage.setPrezime("");
	istrazivaciCreationPage.setJmbg("2928373333212");
	istrazivaciCreationPage.getSaveBtn().click();
	Assert.assertTrue(Utils.isAlertPresent(driver));
Assert.assertTrue(istrazivaciCreationPage.getTextAlert().contains("Морате унети презиме."));
}
	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}
}
