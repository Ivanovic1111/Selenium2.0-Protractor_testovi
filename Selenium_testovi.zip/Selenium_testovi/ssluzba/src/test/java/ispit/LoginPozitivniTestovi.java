package ispit;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import junit.framework.Assert;
import svetlana.minis.helpers.Utils;
import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class LoginPozitivniTestovi {
	public static String getNCharacters(int n) {
		StringBuffer outputBuffer = new StringBuffer(n);
		for (int i = 0; i < n; i++) {
			outputBuffer.append("a");
		}
		return outputBuffer.toString();
	}

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;
	private MenuPage menuPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		// driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		menuPage = new MenuPage(driver);
		// loginPage.login("djura@djuraminis.com", "adminvinca");
	}

	// Pozitivni testovi za login
	@Test
	public void loginSuccessfully() {
		loginPage.login("djura@djuraminis.com", "adminvinca");
		Assert.assertEquals(menuPage.getNaslov(), "MINIS");
		Assert.assertTrue(menuPage.getSerbianFlag().isDisplayed());
	}
	
	
	/*
	 * it('can have digits in it.', function() {
	 * expect(registrationPage.usernameErrors).toEqual([]);
	 * registrationPage.username = 'test123';
	 * expect(registrationPage.usernameErrors).toEqual([]); });
	 */

	// username can have digits in it.Potvrdi da nema poruke o gresci
	@Test
	public void loginPositiveTest() {
		loginPage.setUserName("test123");
		Assert.assertFalse(loginPage.isLogErrorPresent());
	}
@Test
	// Username can have 1 caracter in the field
	public void loginPositiveTest1() {
		loginPage.setUserName(getNCharacters(1));
		Assert.assertFalse(loginPage.isLogErrorPresent());
	}
// Username moze da ima do 50 karaktera u polju
@Test
	public void loginPositiveTest2() {
		loginPage.setUserName(getNCharacters(50));
		Assert.assertFalse(loginPage.isLogErrorPresent());
	}
}