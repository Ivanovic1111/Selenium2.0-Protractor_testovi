package ispit;

import static org.testng.Assert.*;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddInstitucijaNegativni{

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;
	private MenuPage menuPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().setSize(new Dimension(1024, 768));
		// driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		menuPage=new MenuPage(driver);
		loginPage.login("djura@djuraminis.com", "adminvinca");

		WebElement formaOsnovna = instOsnovniPage.getFormaCela();
		assertTrue(formaOsnovna.isDisplayed());

		assertTrue(instOsnovniPage.getNazivInstitucije().isDisplayed());
	}
//Testiranje prazno polje negativni testovi, testiranje da li je dugme "Sacuvaj" Enabled ukoliko se ostavi prazno polje za naziv
@Test
public void setForma(){
	instOsnovniPage.setForm("", "" ,"Srbija", "Beograd","Vuka Karadzica 60", "www.vinnca.com", "test@test.com", "+381655352077", "Fakultet tehničkih nauka");
Assert.assertTrue(instOsnovniPage.getSaveBtn().isEnabled());		
}
//Testiranje da li se pojavila poruka "Morate uneti naziv", ukoliko se ne unese naziv institucije!Test Pass
@Test
public void morateUnetiNaziv(){
	instOsnovniPage.setForm("", "Vincha" ,"Srbija", "Beograd","Vuka Karadzica 60", "www.vinnca.com", "test@test.com", "+381655352077", "Fakultet tehničkih nauka");
	String message="Морате унети назив.";
Assert.assertEquals(instOsnovniPage.getNazivError().getText(),message);		
}
//Prazno email polje
@Test
public void morateUnetiEmail(){
	instOsnovniPage.setForm("Vinca", "Vincha" ,"Srbija", "Beograd","Vuka Karadzica 60", "www.vinnca.com","", "+381652627366", "Fakultet tehničkih nauka");
	String očekivanaPoruka="Морате унети адресу електронске поште.";
	Assert.assertEquals(instOsnovniPage.getEmailError().getText(),očekivanaPoruka);
}
@AfterMethod
public void closeSelenium() {
	// Shutdown the browser
	//logout moze ovde
	driver.quit();
}
}

