package ispit;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.SuccessModalPage;

public class AddInstitucijaBaza{

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private SuccessModalPage successModalPage;
	private String baseUrl;
	private MenuPage menuPage;

	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		successModalPage = new SuccessModalPage(driver);
		menuPage=new MenuPage(driver);
	}
//Testiramo unos nadredjene institucije FTN od strane djura@djuraminis.com
@Test
public void setForma(){
	loginPage.login("djura@djuraminis.com", "adminvinca");
menuPage.getInstitucijaLink().click();
	instOsnovniPage.setForm("Institucija Vinča", "Vinca" ,"Srbija", "Beograd","Vuka Karadzica 60", "www.vinnca.com", "test@test.com", "+381655352077", "Fakultet tehničkih nauka");
Assert.assertTrue(instOsnovniPage.getSaveBtn().isEnabled());		
instOsnovniPage.getSaveBtn().click();
Assert.assertTrue(successModalPage.isPresentModal());

}
@Test
public void setFormaDrugiAdmin(){
	loginPage.login("pera@peraminis.com", "adminftn");
   menuPage.getInstitucijaLink().click();
	instOsnovniPage.setForm("Institut Vinča", "Vinca" ,"Srbija", "Beograd","Vuka Karadzica 89", "www.vinca.com", "test@vinca.uns.ac.rs", "+381655352077", "Institucija Vinča");
Assert.assertTrue(instOsnovniPage.getSaveBtn().isEnabled());		
instOsnovniPage.getSaveBtn().click();
Assert.assertTrue(successModalPage.isPresentModal());
}
@AfterMethod
public void closeSelenium() {
	// Shutdown the browser
	loginPage.getIconLogout().click();
	loginPage.getOdjavaToBeClicked().click();
	driver.quit();
}
}

