package ispit;

import org.openqa.selenium.WebDriver;

public class BaseTest {
	
	public static WebDriver driver;

}
