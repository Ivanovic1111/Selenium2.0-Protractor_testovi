package ispit;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.concurrent.TimeUnit;

import org.hamcrest.core.IsNot;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import svetlana.minis.pages.InstitucijaOsnovniPage;
import svetlana.minis.pages.InstitucijaProjekatPage;
import svetlana.minis.pages.InstitucijaRegistarPage;
import svetlana.minis.pages.LoginPage;
import svetlana.minis.pages.MenuPage;
import svetlana.minis.pages.ObjekatInstPodProjekte;
import svetlana.minis.pages.SuccessModalPage;

public class ProjekatPodaci {

	private WebDriver driver;
	private LoginPage loginPage;
	private InstitucijaRegistarPage instRegistarPage;
	private InstitucijaOsnovniPage instOsnovniPage;
	private InstitucijaProjekatPage instProjekatPage;
	private MenuPage menuPage;
	private String baseUrl;
	private SuccessModalPage modalDialog;
//private ObjekatInstPodProjekte objektiInstitucijePodProjekte;
	@BeforeMethod
	public void setupSelenium() {
		baseUrl = "http://localhost:8080/#/login";
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to(baseUrl);

		loginPage = new LoginPage(driver);
		instRegistarPage = new InstitucijaRegistarPage(driver);
		instOsnovniPage = new InstitucijaOsnovniPage(driver);
		instProjekatPage = new InstitucijaProjekatPage(driver);
		menuPage = new MenuPage(driver);
		modalDialog = new SuccessModalPage(driver);
		//objektiInstitucijePodProjekte = new ObjekatInstPodProjekte(driver);
	}
//Modal da li je prisutan institucija projekat podaci
	@Test
	public void projekatPodaci() {
		assertEquals(baseUrl, driver.getCurrentUrl());
		assertTrue(loginPage.getUserName().isDisplayed());
		assertTrue(loginPage.getPassword().isDisplayed());
		assertTrue(loginPage.getSignInBtn().isDisplayed());

		loginPage.login("djura@djuraminis.com", "adminvinca");

		menuPage.getPodaciZaProjekte().click();
		WebElement formaProjekti = instProjekatPage.getFormCela();
		assertTrue(formaProjekti.isDisplayed());
		instProjekatPage.getRacun().clear();
		instProjekatPage.setRacun("350-2383647584738-22");
		instProjekatPage.setStatusInstitucije("Akreditovan");
		Assert.assertTrue(instProjekatPage.getSaveBtn().isDisplayed());
		instProjekatPage.getSaveBtn().click();
		Assert.assertTrue(modalDialog.isPresentModal());
		modalDialog.exitModal();
	}
	// @ testiramo unos pogresnog formata racuna
	@Test
	public void getPogresanFormatRacuna(){
		loginPage.login("djura@djuraminis.com", "adminvinca");
		menuPage.getPodaciZaProjekte().click();
		WebElement formaProjekti = instProjekatPage.getFormCela();
		//assertTrue(formaProjekti.isDisplayed());
		instProjekatPage.getRacun().clear();
		instProjekatPage.setRacun("350-2383");
		Assert.assertTrue(instProjekatPage.getRacunFormatError().isDisplayed());
		
	}
	// @ Testiramo prazno polje broja racuna
	@Test
	public void getPraznoPoljeBrojaRacuna(){
		loginPage.login("djura@djuraminis.com", "adminvinca");
		menuPage.getPodaciZaProjekte().click();
		WebElement formaProjekti = instProjekatPage.getFormCela();
		assertTrue(formaProjekti.isDisplayed());
		instProjekatPage.setRacun("");
		instProjekatPage.getRacun().clear();
		Assert.assertTrue(instProjekatPage.getRacunError().isDisplayed());
	
	}
	

	@AfterMethod
	public void closeSelenium() {
		// Shutdown the browser
		driver.quit();
	}

}
