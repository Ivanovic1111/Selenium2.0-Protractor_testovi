package svetlana.minis.pages;

import java.util.ArrayList;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class IstrazivaciCreationPage {
	
	private  WebDriver driver;

	public IstrazivaciCreationPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	//gornji tabovi
	
	public WebElement getLicniPodaci() {
		return Utils.waitForElementPresence(driver,By.xpath("//a/tab-heading[text()='Lični podaci']/.."),10);
	}
	
	public WebElement getPodaciRegistar() {
		return Utils.waitForElementPresence(driver,By.xpath("//a/tab-heading[text()='Podaci za registar']/.."),10);
	}
	
	public WebElement getPodaciProjekat() {
		return Utils.waitForElementPresence(driver,By.xpath("//a/tab-heading[text()='Podaci za projekte']/.."),10);
	}
	
	// ime 
	
	public WebElement getIme() {
		return Utils.waitForElementPresence(driver,By.xpath("//input[@name='firstNameText']"),10);
	}
	
	public void setIme(String ime) {
		WebElement imePolje = this.getIme();
		imePolje.clear();
		imePolje.sendKeys(ime);
	}
	
	public WebElement getImeError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Морате унети име.']"),10);
	}
	
	// prezime
	
	public WebElement getPrezime() {
		return Utils.waitForElementPresence(driver,By.xpath("//div[@name='personSearchLastNameT']/input"),10);
	}
	
	public void setPrezime(String prezime) {
		WebElement prezimePolje = this.getPrezime();
		prezimePolje.clear();
		prezimePolje.sendKeys(prezime);
	}
	
	
	// jmbg
	
	public WebElement getJmbg() {
		return Utils.waitForElementPresence(driver,By.xpath("//input[@name='jmbg']"),10);
	}
	
	public void setJmbg(String jmbg) {
		WebElement jmbgPolje = this.getJmbg();
		jmbgPolje.clear();
		jmbgPolje.sendKeys(jmbg);
	}
	
	public WebElement getjmbgError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Morate uneti JMBG.']"),10);
	}
	public WebElement getDatum() {
		return Utils.waitForElementPresence(driver,By.cssSelector(".datepicker"),10);
	}
	public void setDatum(String value){
		WebElement datumi = this.getDatum();
		datumi.clear();
		datumi.sendKeys(value);
	}
	public WebElement getDatumError(){
		return Utils.waitForElementPresence(driver,By.cssSelector("div.ng-isolate-scope:nth-child(5) > div:nth-child(2) > span:nth-child(3)"), 10);
		
	}
	//Proba istrazivaci titula multiple select
//<select name="personTitle" ng-model="data.title" class="form-control ng-pristine ng-valid ng-scope ng-touched"><option value="? undefined:undefined ?"></option><option value="none" class="ng-binding">нема</option><option value="dr">Dr</option><option value="mr">Mr</option></select>
	//titula istrazivaca1
	public Select getTituleMultipleSelect(){
		return new Select (Utils.waitForElementPresence(driver, By.name("personTitle"), 10));
	}
	//njihov kao primer1
	/*public Select getNastavniciSelect() {
		return new Select(Utils.waitForElementPresence(driver, By.name("nastavnici"), 10));
	}*/

	/**
	 * 
	 * @param nastavnici
	 *            Lista nastavnika koja ce biti selektovana "Ime Prezime",
	 *            "Ime Prezime"..
	 */
	/*public void setNastavniciByLabel(ArrayList<String> nastavnici) {
		Select nastavnikSelect = this.getNastavniciSelect();
		for (String nastavnik : nastavnici) {
			nastavnikSelect.selectByVisibleText(nastavnik);
		}*/
	//****************************************************
	public void setTitulaByLabel(ArrayList<String>personTitle){
		Select tituleToBeSelect=this.getTituleMultipleSelect();
		for(String titula : personTitle){
			tituleToBeSelect.selectByVisibleText(titula);
			//************************************************
			//ovo ide u test
		/*	ArrayList<String> personTitle = new ArrayList<String>();
			personTitle.add("нема");
			personTitle.add("Dr");
			istrazivaciCreationPage.setTitulaByLabel(personTitle);*/
		}
	}
	// buttoni
	
	public WebElement getSaveBtn() {
		return Utils.waitToBeClickable(driver,By.cssSelector(".btn.btn-lg.btn-success.ng-binding"),20);
	}

	public WebElement getCancelBtn() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Basic']//button//text()[contains(.,' Одустани')]/.."),20);
	}
	//Neki moj multiple select
	public  void selectTheDropDownList(String text)
	{
	WebElement dropDown=Utils.waitForElementPresence(driver,By.name("personTitle"), 10);//ovde menjam selektore
	    Select select = new Select(dropDown);
	    select.selectByVisibleText(text);       
	}
public String getTextAlert(){
	Alert alert = driver.switchTo().alert();
	return alert.getText();
}
	//u @Test bi islo onda
	/*Utils.selectTheDropDownList(dropDown,text1);
	Utils.selectTheDropDownList(dropDown,text2);*/
	//Istrazivaci podaci za registrar

}
