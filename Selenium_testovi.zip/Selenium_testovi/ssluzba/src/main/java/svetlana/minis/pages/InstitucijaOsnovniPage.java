package svetlana.minis.pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class InstitucijaOsnovniPage {
	
	private WebDriver driver;
	public InstitucijaOsnovniPage(WebDriver driver) {
		
		this.driver = driver;

	}
	//div[@title='Identifikacioni broj u ministarstvu']//input[@name='mntrID']
	public WebElement getFormaCela() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Basic']"),20);
	}
	//BUTTON[@ng-disabled='loadingCounter<10'])[2]/preceding-sibling::BUTTON
	//div[@class='form-group']//div[@class='pull-right']//button[@class='btn btn-lg btn-brown']/following-sibling::i[@class='fa fa-check']
	public WebElement getSaveBtn() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Basic']//button//text()[contains(.,'Сачувај')]/.."),20);
	}
	
	public WebElement getCancelBtn() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Basic']//button//text()[contains(.,'Одустани')]/.."),20);
	}
	
	// naziv Institucije
	
	public WebElement getNazivInstitucije() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='name']"), 10);
	}
	
	public void setNazivInstitucije(String naziv) {
		WebElement nazivInst = this.getNazivInstitucije();
		nazivInst.clear();
		nazivInst.sendKeys(naziv);
	}
	
	// naziv Institucije na engleskom
	
	public WebElement getNazivInstitucijeEng() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='eng_name']"), 10);
	}
	
	public void setNazivInstitucijeEng(String naziv) {
		WebElement nazivInstEng = this.getNazivInstitucijeEng();
		nazivInstEng.clear();
		nazivInstEng.sendKeys(naziv);
	}
	
	
	// Drzava

	public WebElement getDrzava(){
		return Utils.waitForElementPresence(driver, By.xpath(("//div[@class='col-sm-6 col-print-6']//select[@name='state']/..")), 10);
	}
	
	public Select getDrzavaSelect() {
		return new Select(Utils.waitForElementPresence(driver, By.name("state"), 10));
	}
	
	public void setDrzavaByLabel(String drzava) {
		Select drzave = this.getDrzavaSelect();
		drzave.selectByVisibleText(drzava);
	}
	//odmah klikne na drzavu samo promenim value
	public void getKlikniNaDrzavuSelect() {
		Select drzave = this.getDrzavaSelect();
		drzave.selectByValue("-1");
	}
	// za helper metodu dodaj drzavu
	public WebElement getImeNoveDrzave(){
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='stateName']"), 10);
	}
	// za helper metodu dodaj drzavu

	public WebElement getOpisNoveDrzave(){
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='stateDescription']"), 10);
	}
	
		
	public WebElement getConfirmButton(){
		return Utils.waitForElementPresence(driver, By.xpath("//div[@class='col-sm-3 text-right']/button"), 10);
	}
	// Helper metoda koja unosi drzavu i opis u jednom potezu, a pre toga moramo da kliknemo getKlikniNaDrzavuSelect, za dodavanje vec postojece drzave promenimo value
	public void unesiNovuDrzavu(String drzava, String opis) {
		//this.getNovaDrzavaAppear();
		// Daj mi polje naziv
		WebElement novaDrzava = this.getImeNoveDrzave();
		novaDrzava.sendKeys(drzava);
		//Daj mi polje ime
		WebElement opisDrzave = this.getOpisNoveDrzave();
		opisDrzave.sendKeys(opis);
		this.getConfirmButton().click();
	}
	//Metoda koja vraca teks da bude jednak imenu drzave
	public String getSelectedState() {
		return Utils.waitForElementPresence(driver, By.cssSelector("select[name=state] option:checked"), 10).getText();
	}
		
	// Mesto
	
	public WebElement getMesto() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='place']"), 10);
	}
	
	public void setMesto(String mesto) {
		WebElement nazivMesta = this.getMesto();
		nazivMesta.clear();
		nazivMesta.sendKeys(mesto);
	}
		
	// Opstina
	
	public WebElement getOpstina() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='townShipText']"), 10);
	}
	
	public void setOpstina(String opstina) {
		WebElement nazivOpstine = this.getOpstina();
		nazivOpstine.clear();
		nazivOpstine.sendKeys(opstina);
	}
		
	// Adresa
	
	public WebElement getAdresa() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='address']"), 10);
	}
	
	public void setAdresa(String adresa) {
		WebElement nazivAdrese = this.getAdresa();
		nazivAdrese.clear();
		nazivAdrese.sendKeys(adresa);
	}
	
	// Web adresa
	
	public WebElement getWebAdresa() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='uri']"), 10);
	}
	
	public void setWebAdresa(String adresa) {
		WebElement nazivWebadrese = this.getWebAdresa();
		nazivWebadrese.clear();
		nazivWebadrese.sendKeys(adresa);
	}
		
	// Elektronska posta
	
	public WebElement getEmailAdresa() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='email']"), 10);
	}
	
	public void setEmailAdresa(String email) {
		WebElement nazivEmailAdrese = this.getEmailAdresa();
		nazivEmailAdrese.clear();
		nazivEmailAdrese.sendKeys(email);
	}
	
	// Telefon
	
	public WebElement getTelefon() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='phone']"), 10);
	}
	
	public void setTelefon(String telefon) {
		WebElement nazivTelefon = this.getTelefon();
		nazivTelefon.clear();
		nazivTelefon.sendKeys(telefon);
	}
	
	// Skraceni naziv
	
	public WebElement getSkraceniNaziv() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='acro']"), 10);
	}
	
	public void setSkraceniNaziv(String skrNaziv) {
		WebElement skraceniNaziv = this.getSkraceniNaziv();
		skraceniNaziv.clear();
		skraceniNaziv.sendKeys(skrNaziv);
	}
	
	// Setovanje institucije
	
		public WebElement getListaInstitucija(){
			return Utils.waitForElementPresence(driver,By.xpath("//a[@class='select2-choice']"),10);
		}
		
		public WebElement getUnosBtn(){
			return Utils.waitForElementPresence(driver,By.id("s2id_autogen2_search"),10);
		}
		
		public void setUnosBtn(String unos){
			WebElement unosPolje = this.getUnosBtn();
			unosPolje.clear();
			unosPolje.sendKeys(unos + "\n");
			
		}
		
		public WebElement getOption(String opcija){
			return Utils.waitForElementPresence(driver,By.xpath("//option[text()=" +"\'" +opcija + "\']"),10);
		}
		
		//cela institucija
		public void setNadredjenaInstitucija(String unos) {
			this.getListaInstitucija().click();
			this.setUnosBtn(unos);
			// ovo je metoda ako se zabunim koji select mi treba
//			Select dropdown = new Select(driver.findElement(By.name("supetInstitution")));
//			dropdown.selectByVisibleText(opcija);
			
		}
	
	// Cela forma
		
		public void setForm(String nazivInstitucije, String nazivNaEngleskom, String drzava, String mesto, String adresa,String webAdresa,
			String email, String telefon,String nadredjenaInstitucija) {
			this.setNazivInstitucije(nazivInstitucije);
			this.setNazivInstitucijeEng(nazivNaEngleskom);
			this.setDrzavaByLabel(drzava);
			this.setMesto(mesto);
			this.setAdresa(adresa);
			this.setWebAdresa(webAdresa);
			this.setEmailAdresa(email);
			this.setTelefon(telefon);
		    this.setNadredjenaInstitucija(nadredjenaInstitucija);
	     
		}
	
	// Cela forma sa novom drzavom
	
	public void setFormWithNewState(String nazivInstitucije, String drzava, String opisDrzave) {
		this.setNazivInstitucije(nazivInstitucije);
		this.getKlikniNaDrzavuSelect();
		this.unesiNovuDrzavu(drzava, opisDrzave);
		
	}
	
	// Greske
	
	public WebElement getNazivError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Морате унети назив.']"),10);
	}
	
	public WebElement getMestoError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети место.']"), 10);
		}
	
	public WebElement getAdresaError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети адресу.']"), 10);
	}
	
	public WebElement getWebAdresaError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети веб адресу.']"), 10);
	}
	
	public WebElement getEmailError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети адресу електронске поште.']"), 10);
	}
	
	public WebElement getTelefonError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети број телефона.']"), 10);
	}
}
