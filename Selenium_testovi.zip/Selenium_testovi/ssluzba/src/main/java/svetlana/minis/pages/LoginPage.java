package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class LoginPage {
	
	public WebDriver driver;

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	// username
	
	public WebElement getUserName() {
		return Utils.waitForElementPresence(driver, By.id("username"), 10);
	}
	
	public void setUserName(String userName) {
		WebElement userNameInp = this.getUserName();
		userNameInp.clear();
		userNameInp.sendKeys(userName);
	}

	// password
	
	public WebElement getPassword() {
		return Utils.waitForElementPresence(driver, By.id("password"), 10);
	}
	
	public void setPassword(String password) {
		WebElement passwordInp = this.getPassword();
		passwordInp.clear();
		passwordInp.sendKeys(password);
	}
	
	public WebElement getSignInBtn() {
		return Utils.waitForElementPresence(driver, By.className("btn-info"), 10);
	}
	
	public void login (String userName, String password) {
		this.setUserName(userName);
		this.setPassword(password);
		this.getSignInBtn().click();
	}
	
	public WebElement getCancelBtn() {
		return Utils.waitForElementPresence(driver, By.className("btn-danger"), 10);
	}
	
	public WebElement getLogError(){
	//	return driver.findElements(By.xpath("//h4//span/following-sibling::text()")).get(1);
		return driver.findElement(By.xpath("//li[text()='Pogrešno korisničko ime ili lozinka!']"));
		
	}
	public boolean  isLogErrorPresent(){
		//	return driver.findElements(By.xpath("//h4//span/following-sibling::text()")).get(1);
			return Utils.isPresent(driver, (By.xpath("//li[text()='Pogrešno korisničko ime ili lozinka!']")));
	}
//	<img src="app/assets/images/logo.png" class="user-image" alt="User Image"> kliknemo za odjavu i onda select za odjava
//css  je .user-image
	public WebElement getIconLogout(){
		return  Utils.waitForElementPresence(driver, By.cssSelector(".user-image"), 10);
	}
	public WebElement getOdjavaToBeClicked() {
		return  Utils.waitForElementPresence(driver, By.xpath("//span[@translate='LOGOUT']"), 10);
	}
	public WebElement getUsernameError() {
		return  Utils.waitForElementPresence(driver, By.xpath("//span[@text()='Korisničko ime obavezno']"), 10);
	}
	public WebElement getPasswordError() {
		return  Utils.waitForElementPresence(driver, By.xpath("//span[@text()='Lozinka obavezna]"), 10);
	}
}

