package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import svetlana.minis.helpers.Utils;

public class ObjekatInstPodProjekte {

	private WebDriver driver;

	public ObjekatInstPodProjekte(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public WebElement getBrojRacunaIsDisplayed() {
		return Utils.waitForElementPresence(driver,By.xpath("//*[@id='page-content']/div/div/div/div/div/div/div/div/div/div[3]/ng-include/div[2]/div/div/div/div[2]/form/div[1]/label"),20);
	}
	
	public WebElement getIdentifikacioniBrojUMinistrastvuDisplayed() {
		return Utils.waitForElementPresence(driver,By.xpath("//label[text()='Идентификациони број у министарству']"),20);
	}

/*	public WebElement getStatusInstitucijeDisplayed() {
		return Utils.waitForElementPresence(driver,By.xpath("//label[text()='	Статус институције *']"),20);
	}*/
	

}