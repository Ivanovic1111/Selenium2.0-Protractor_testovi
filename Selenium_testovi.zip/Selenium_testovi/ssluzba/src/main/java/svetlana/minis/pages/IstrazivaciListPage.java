package svetlana.minis.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import svetlana.minis.helpers.Utils;

public class IstrazivaciListPage {

	public WebDriver driver;

	public IstrazivaciListPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getDodajIstrazivaca() {
		return Utils.waitForElementPresence(driver,By.xpath("//a[@ui-sref='addPerson']"),10);
	}
	
	public WebElement getIstrazivaciTable() {
		return Utils.waitForElementPresence(driver,By.xpath("//*[@id='page-content']//table"),10);
	}
	
	public List<WebElement> getTableRows() {
		return this.getIstrazivaciTable().findElements(By.tagName("tr"));
	}
	
	public boolean isIstrazivacInTable(String prezime) {
		return Utils.isPresent(driver, By.xpath("//*[contains(text(),\"" + prezime + "\")]/../.."));
	}
	
	public WebElement getIstrazivacRowByPrezime(String prezime) {
		return Utils.waitForElementPresence(driver, By.xpath("//*[contains(text(),\"" + prezime + "\")]/../.."), 10);
	}

}
