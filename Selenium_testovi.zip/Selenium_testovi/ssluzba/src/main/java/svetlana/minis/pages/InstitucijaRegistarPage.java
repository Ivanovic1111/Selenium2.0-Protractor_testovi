package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class InstitucijaRegistarPage {

	private WebDriver driver;

	public InstitucijaRegistarPage(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getForm() {
		return Utils.waitForElementPresence(driver, By.xpath("//form[@name='Register']"), 20);
	}

	// PIB (obavezno polje)

	public WebElement getPib() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='pib']"), 10);
	}

	public void setPib(String pib) {
		WebElement pibPolje = this.getPib();
		pibPolje.clear();
		pibPolje.sendKeys(pib);
	}

	public WebElement getPibError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети ПИБ.']"), 10);
	}

	public String getPibLabelText() {
		return Utils.waitForElementPresence(driver, By.xpath("//label[contains(text(),'Poreski')]"), 10).getText();
	}

	// Maticni broj (obavezno polje)

	public WebElement getMaticniBroj() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='maticniBroj']"), 10);
	}

	public void setMaticniBroj(String maticniBroj) {
		WebElement maticniBrojPolje = this.getMaticniBroj();
		maticniBrojPolje.clear();
		maticniBrojPolje.sendKeys(maticniBroj);
	}

	public WebElement getMaticniBrojError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Унесите матични број.']"), 10);
	}

	public WebElement getMaticniBrojLabelText() {
		return Utils.waitForElementPresence(driver,
				By.xpath("//span[text()='Матични број се мора састојати од 13 цифара.']"), 10);
	}

	// Broj poslednje naucne akreditacije (obavezno polje)

	public WebElement getBrojPoslednjeAkred() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='accreditationNumber']"), 10);
	}

	public void setBrojPoslednjeAkred(String akreditacija) {
		WebElement brojPoslednjeAkred = this.getBrojPoslednjeAkred();
		brojPoslednjeAkred.clear();
		brojPoslednjeAkred.sendKeys(akreditacija);
	}

	public WebElement getBrojPoslednjeAkredError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Морате унети број акредитације.']"), 10);
	}

	// Datum poslednje naucne akreditacije (obavezno polje)

	public WebElement getDatumPoslednjeAkred() {
		return Utils.waitForElementPresence(driver,
				By.xpath(("//em-date-time-picker[@name='accreditationDate']/span/div/input")), 10);

	}

	public void setDatumPoslednjeAkred(String datumAkred) {
		WebElement datumAkredPolje = this.getDatumPoslednjeAkred();
		datumAkredPolje.clear();
		datumAkredPolje.sendKeys(datumAkred);
	}

	public WebElement getDatumPoslednjeAkredError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Унесите датум акредитације.']"), 10);
	}

	// Naziv institucije iz akreditacije (obavezno polje)

	public WebElement getNazivInsitucijeAkred() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='accreditationNote']"), 10);
	}

	public void setNazivInstitucijeAkred(String instAkreditacija) {
		WebElement nazivInstitucijeAkred = this.getNazivInsitucijeAkred();
		nazivInstitucijeAkred.clear();
		nazivInstitucijeAkred.sendKeys(instAkreditacija);
	}

	public WebElement getNazivInstitucijeAkredError() {
		return Utils.waitForElementPresence(driver,
				By.xpath("//span[text()='Морате унети назив институције из акредитације.']"), 10);
	}

	// Napomena o registru

	public WebElement getNapomenaORegistru() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='note']"), 10);
	}

	public void setNapomenaORegistru(String napomena) {
		WebElement napomenaOReg = this.getNapomenaORegistru();
		napomenaOReg.clear();
		napomenaOReg.sendKeys(napomena);
	}

	// Vrsta institucije (obavezno polje) ne radi!!!

	public Select getInstitucijaSelect() {
		return new Select(Utils.waitForElementPresence(driver, By.name("institutionType"), 10));
	}

	public void setInstitucijaByLabel(String institucija) {
		Select institucije = this.getInstitucijaSelect();
		institucije.selectByVisibleText(institucija);

	}

	// Instituciju koju cekiramo da je jednaka nazivu institucije
	public String getSelectedInstitucija() {
		return Utils.waitForElementPresence(driver, By.cssSelector("select[name=institutionType] option:checked"), 10)
				.getText();
	}

	// Osnovna delatnost institucije ne radi!!!

	// Osnivac

	public WebElement getOsnivac() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='founder']"), 10);
	}

	public void setOsnivac(String osnivac) {
		WebElement osnivacPolje = this.getOsnivac();
		osnivacPolje.clear();
		osnivacPolje.sendKeys(osnivac);
	}

	// Datum

	public WebElement getDatum() {
		return Utils.waitForElementPresence(driver, By.xpath(("//em-date-time-picker[@name='date']/span/div/input")),
				10);
	}

	public void setDatum(String datum) {
		WebElement datumPolje = this.getDatum();
		datumPolje.clear();
		datumPolje.sendKeys(datum);
	}

	// Broj resenja o osnivanju

	public WebElement getBrojResenjaOOsnivanju() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='rescriptNumber']"), 10);
	}

	public void setBrojResenjaOOsnivanju(String brojResenja) {
		WebElement brojResenjaPolje = this.getBrojResenjaOOsnivanju();
		brojResenjaPolje.clear();
		brojResenjaPolje.sendKeys(brojResenja);
	}

	// Vlasnicka struktura (obavezno polje)

	public WebElement getVlasnickaStruktura() {
		return Utils.waitForElementPresence(driver,
				By.xpath("//div[@class='col-sm-6 col-print-6']//select[@name='ownershipStructure']/.."), 10);
	}

	public Select getVlasnickaStrukturaSelect() {
		return new Select(Utils.waitForElementPresence(driver, By.name("ownershipStructure"), 10));
	}

	// Prosledjujemo String Drzavna, Privatna ili Mesovita
	public void setVlasnickaStrukturaByLabel(String vlasStruktura) {
		Select vlasnistvo = this.getVlasnickaStrukturaSelect();
		vlasnistvo.selectByVisibleText(vlasStruktura);
	}

	public WebElement getPIBError() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[text()='Порески број није у добром формату.']"),
				10);

	}

	public void setInstitucijaPodaciZaRegistar(String pib, String maticniBroj, String akreditacija, String datumAkred,
			String instAkreditacija, String institucija, String vlasStruktura) {

		this.setPib(pib);
		this.setMaticniBroj(maticniBroj);
		this.setBrojPoslednjeAkred(akreditacija);
		this.setDatumPoslednjeAkred(datumAkred);
		this.setNazivInstitucijeAkred(instAkreditacija);
		this.setInstitucijaByLabel(institucija);
		this.setVlasnickaStrukturaByLabel(vlasStruktura);

	}

	// ovo prolazi буттонс
	public WebElement getSaveBtn() {
		return Utils.waitForElementPresence(driver,
				By.xpath("//form[@name='Register']//button//text()[contains(.,' Сачувај')]/.."), 20);
	}

	public WebElement getCancelBtn() {
		return Utils.waitForElementPresence(driver,
				By.xpath("//form[@name='Register']//button//text()[contains(.,'Одустани')]/.."), 20);
	}

}
/*
 * Морате унети ПИБ. Матични број * Унесите матични број. Број последње научне
 * акредитације * Морате унети број акредитације. Датум последње научне
 * акредитације * Унесите датум акредитације. Назив институције из акредитације
 * * Морате унети назив институције из акредитације. Напомена о регистру Врста
 * институције * Морате изабрати врсту институције.
 */