package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import svetlana.minis.helpers.Utils;

public class SuccessModalPage {
	
	private WebDriver driver;

	public SuccessModalPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	public boolean isPresentModal() {
		return Utils.isPresent(driver, By.xpath("//h4[text()='SUCCESS']/.."));
	}
	
	public WebElement getModal() {
		return Utils.waitForElementPresence(driver,By.xpath("//h4[text()='SUCCESS']/.."),10);
		
	}
	
	public WebElement getmodalX(){
		return Utils.waitForElementPresence(driver,By.xpath("//span[@class='fa fa-times']"),10);
	}
	
	public void exitModal() {
		Actions act = new Actions(driver);
		WebElement modal = this.getModal();//nasli smo x na modalnom dijalogu
		act.moveToElement(modal).build().perform();
		this.getmodalX().click();
	}
	public String getAlertText(){
		return Utils.waitForElementPresence(driver, By.xpath("//*[@id='page-content']/div/div/div/div/div/div/div/div/div/div[1]/ng-include/div/div/div/div/div[2]/form[3]/div[2]/div/span"),10).getText();
	}
/*	//Multiple select start
	//ovde dodajemo selektor
	public WebElement getselectorByName(){
		return Utils.waitForElementPresence(driver, selector, 10);
	}
	public void getMultipleSelectKeys(WebDriver driver){
	   Actions builder = new Actions(driver);
	WebElement  elementName=Utils.waitForElementPresence(driver, selector, 10);
	  WebElement selectorvalue1=this.getSelectFirstValue();
	   WebElement selectorvalue2=this.getSElectSEcondValue();
	   builder.keyDown(Keys.CONTROL)
	       .click(selectorvalue1)
	       .click(selectorvalue2)
	       .keyUp(Keys.CONTROL);
	//Then get the action:
	   Action selectMultiple = builder.build();
	//And execute it:
	   selectMultiple.perform();
	}*/
}
