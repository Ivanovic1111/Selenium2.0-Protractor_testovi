package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class InstitucijaProjekatPage {
	
	private WebDriver driver;

	public InstitucijaProjekatPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public WebElement getFormCela() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Project']"),20);
	}

	public WebElement getSaveBtn() {
		return Utils.waitToBeClickable(driver,By.xpath(".//*[@id='page-content']/div/div/div/div/div/div/div/div/div/div[3]/ng-include/div[2]/div/div/div/div[2]/form/div[6]/div[2]/div/button[2]"),20);
	}
	
	public WebElement getCancelBtn() {
		return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Project']//button//text()[contains(.,'одустани')]/.."),20);
	}
	
	// Broj racuna (obavezno polje)
	
	public WebElement getRacun() {
		return Utils.waitForElementPresence(driver,By.xpath("//input[@name='account']"),10);
	}
	
	public void setRacun(String racun){
		WebElement racunPolje = this.getRacun();
		//racunPolje.clear();
		racunPolje.sendKeys(racun);
	}
	
	public WebElement getRacunError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Морате унети број рачуна.']"),10);
	}
	public WebElement getRacunFormatError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Broj računa mora biti u formatu XXX-XXXXXXXXXXXXX-XX.']"),10);
	}
	
	public String getRacunLabelText() {
		return Utils.waitForElementPresence(driver,By.xpath("//label[contains(text(),'Broj računa')]"),10).getText();
	}
	
	// Identifikacioni broj u ministarstvu Enabled = false
		
	public WebElement getIdentBrojUMinistarstvu() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='mntrID']"), 10);
	}
	
	public void setIdentBrojUMinistarstvu(String identBrojUMinis) {
		WebElement identBroj = this.getIdentBrojUMinistarstvu();
		identBroj.clear();
		identBroj.sendKeys(identBrojUMinis);
	}
	
	// Identifikacioni broj na medjunarodnom nivou
	
	public WebElement getIdentBrojMedjunarodni() {
		return Utils.waitForElementPresence(driver, By.xpath("//input[@name='orcid']"), 10);
	}
	
	public void setIdentBrojMedjunarodni(String identBrojMedj) {
		WebElement identBrojMedjun = this.getIdentBrojMedjunarodni();
		identBrojMedjun.clear();
		identBrojMedjun.sendKeys(identBrojMedj);
	}
	
	// Status institucije (obavezno polje) (select)
	
	public Select getStatusInstitucije() {
		return new Select(Utils.waitForElementPresence(driver, By.xpath("//select[@name='institutionStatus']"), 10));
	}
	
	public void setStatusInstitucije(String value) {
		this.getStatusInstitucije().selectByVisibleText(value);
	}
	public WebElement getStatusInstitucijeError() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Morate izabrati status institucije.']"),10);
	}
	// Oblast istrazivanja Disabled
	public WebElement getOblastIstrazivanja() {
		return Utils.waitForElementPresence(driver, By.id("s2id_autogen6"), 10);
	}

}
