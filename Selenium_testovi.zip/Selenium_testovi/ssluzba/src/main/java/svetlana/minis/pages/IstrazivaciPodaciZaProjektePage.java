package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import svetlana.minis.helpers.Utils;

public class IstrazivaciPodaciZaProjektePage {
	
	public WebDriver driver;

	public IstrazivaciPodaciZaProjektePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	//prvo moraju biti popunjeni licni podaci , pa klik na podaci za registar
	// Kategorije istrazivaca
	
	public WebElement getKategorijeIstrazivaca() {
		return Utils.waitForElementPresence(driver,By.id("s2id_autogen2"),10);
	}

	public void setKategorijeIstrazivanja(String kategorija) {
		WebElement kategorijeIstrazivanjaPolje = this.getKategorijeIstrazivaca();
		kategorijeIstrazivanjaPolje.clear();
		kategorijeIstrazivanjaPolje.sendKeys(kategorija);
	}
	
	// Buttoni

		public WebElement getSaveBtn() {
			return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Project']//button//text()[contains(.,'Сачувај')]/.."),20);
		}
		
		public WebElement getCancelBtn() {
			return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Project']//button//text()[contains(.,' Одустани')]/.."),20);
		}

}
