/*package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import svetlana.minis.helpers.Utils;

public class IstrazivaciPodaciRegistarPage {
	public WebDriver driver;

	public IstrazivaciPodaciRegistarPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	// Bibliografija
	
		public WebElement getBibliografija() {
			return Utils.waitForElementPresence(driver,By.xpath("//input[@name='bibliography']"),10);
		}
		
		public void setBibliografija(String bibliografija) {
			WebElement bibliografijaPolje = this.getBibliografija();
			bibliografijaPolje.clear();
			bibliografijaPolje.sendKeys(bibliografija);
		}
		
	// Oblast istrazivanja
		
		public WebElement getOblastIstrazivanja() {
			return Utils.waitForElementPresence(driver, By.xpath("//input[@name='researchAreas']"), 10);
		}
		
		public void setOblastIstrazivanja(String oblastIstrazivanja) {
			WebElement oblastIstrazivanjaPolje = this.getOblastIstrazivanja();
			oblastIstrazivanjaPolje.clear();
			oblastIstrazivanjaPolje.sendKeys(oblastIstrazivanja);
		}

		// Identifikacioni broj u Ministarstvu
		
		public WebElement getIdentBrojUMinistarstvu() {
			return Utils.waitForElementPresence(driver, By.xpath("//input[@name='mntrn']"), 10);
		}
		
		public void setIdentBrojUMinistarstvu(String identBrojUMinistarstvu) {
			WebElement identBrojUMinistarstvuPolje = this.getIdentBrojUMinistarstvu();
			identBrojUMinistarstvuPolje.clear();
			identBrojUMinistarstvuPolje.sendKeys(identBrojUMinistarstvu);
		}
		
		// Napomena
		
		public WebElement getNapomena() {
			return Utils.waitForElementPresence(driver, By.xpath("//input[@name='note']"), 10);
		}
		
		public void setNapomena(String napomena) {
			WebElement napomenaPolje = this.getNapomena();
			napomenaPolje.clear();
			napomenaPolje.sendKeys(napomena);
		}
		//Error
		public WebElement getBibliografijaError(){
			return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Морате унети библиографију.']"), 10);
		}
		public WebElement getOblastIstrazivanjaError(){
			return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Унесите области истраживања.']"), 10);
		}
		public WebElement getIdentifikacioniBrojUMinistarstvuError(){
			return Utils.waitForElementPresence(driver,By.xpath("//span[text()='Морате унети идентификациони број у министарству.']"), 10);
		}
		// Buttoni
		

		public WebElement getSaveBtn() {
			return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Register']//button//text()[contains(.,' Сачувај)]/.."),20);
		}
		
		public WebElement getCancelBtn() {
			return Utils.waitForElementPresence(driver,By.xpath("//form[@name='Register']//button//text()[contains(.,' Одустани')]/.."),20);
		}
		//Neki moj multiple select
		public  void selectTheDropDownList(String text)
		{
		WebElement dropDown=Utils.waitForElementPresence(driver,By.name("personTitle"), 10);//ovde menjam selektore
		    Select select = new Select(dropDown);
		    select.selectByVisibleText(text);       
		}
}
*/