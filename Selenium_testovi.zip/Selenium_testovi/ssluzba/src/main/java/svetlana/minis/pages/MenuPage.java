package svetlana.minis.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import svetlana.minis.helpers.Utils;

public class MenuPage {
	
	public WebDriver driver;

	public MenuPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	//Основни подаци
	public WebElement getOsnovniPodaci() {
		return Utils.waitToBeClickable(driver,By.xpath("//a/tab-heading[text()='Osnovni podaci']/.."),10);
	}
	
	public WebElement getPodaciZaRegistar() {
		return Utils.waitToBeClickable(driver,By.cssSelector(".nav-tabs > li:nth-child(2) > a:nth-child(1) > tab-heading:nth-child(1)"),10);
	}
	
	public WebElement getPodaciZaProjekte() {
		return Utils.waitToBeClickable(driver,By.xpath("//tab-heading[text()='Подаци за пројекте']"),10);
	}
	//dodaj istrazivaca css .//*[@id='page-content']/div/div/div/div/div/div/div/div[1]/a
	//Ovo je додај истраживача
	//na link moze css ako nam ne treba text
	public WebElement getIstrazivaci() {
		return Utils.waitForElementPresence(driver, By.cssSelector(".//*[@id='page-content']/div/div/div/div/div/div/div/div[1]/a"), 10);
	}
	
	public WebElement getInstitucijaLink() {
		return Utils.waitForElementPresence(driver,By.xpath("//a[@ui-sref='adminInstitution']"),10);
	}
	//a/descendant::i/span[contains(text(), 'Istraživač')]
	public WebElement getIstrazivaciLink() {
		return Utils.waitForElementPresence(driver, By.xpath("//span[contains(text(), 'Истраживачи')]"),10);
		//return Utils.waitForElementPresence(driver,By.xpath("//a[@ui-sref='persons']/span"),10);
	}
	
	//ово је да се асертује да је Минис наслов
	public String getNaslov() {
		return Utils.waitForElementPresence(driver,By.xpath("//span[@class='logo-lg']/b"),10).getText();
	}
	public boolean getMinisNaslov(){
		return Utils.waitForElementPresence(driver,By.xpath("//span[@class='logo-lg']/b"),10).getText().contains("MINIS");
	}
	// ово нам служи да се вратимо на почетак
	public WebElement getNaslovClick(){
		return Utils.waitForElementPresence(driver,By.xpath("//span[@class='logo-lg']/b"),10);

	}
	//<img src="app/assets/images/srb.png" height="15px">
	public WebElement getSerbianFlag() {
		return Utils.waitForElementPresence(driver,By.xpath("//img[@src='app/assets/images/srb.png']"),10);
	}
	

}
